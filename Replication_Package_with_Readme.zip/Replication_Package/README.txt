REPLICATION PACKAGE

This folder contains materials to reproduce the portfolio analysis and related survey-based findings.

FOLDER STRUCTURE
-----------------
- code/
    * portfolio_analysis.ipynb
      Jupyter notebook that summarizes portfolios and generates key results.

    * capm_portfolio_project.ipynb
      Main FIN411X CAPM portfolio project notebook.

- data/
    * chatgpt_survey_raw.csv
      Raw data exported from Google Forms for the "AI Literacy and Metacognition: ChatGPT Survey".

- documentation/
    * chatgpt_survey_instrument.pdf
      PDF of the Google Forms survey instrument corresponding to the survey data.

    * python_code_notes.docx
      Original notes or description of the Python code.

- output/
    * summary_all_portfolios.csv
      Output file containing summary statistics for all portfolios.

REPLICATION NOTES
-----------------
1. Open the notebooks in the code/ folder using Jupyter or a compatible environment.
2. Ensure that the relative paths to files in data/ and output/ remain unchanged.
3. The environment requirements (Python version, libraries) should be described
   in python_code_notes.docx or within the notebooks themselves (see top cells).

If something is unclear, you may want to add more details here about:
- required Python packages and versions
- any random seeds used
- exact steps to run each notebook end-to-end.

ENVIRONMENT & SOFTWARE REQUIREMENTS
-----------------------------------
The analysis was developed and tested in a standard Python data science environment.
You can use one of the following options:
  - Jupyter Notebook (local Anaconda / Miniconda installation)
  - JupyterLab
  - VS Code with the Python extension and Jupyter support
  - Google Colab (upload this replication package to your Google Drive)

Recommended setup (edit this to match your exact environment if needed):
  - Python: 3.9 or later
  - Recommended packages:
      * numpy
      * pandas
      * matplotlib
      * seaborn
      * scipy
      * statsmodels
  - Optional packages (if used in your notebooks):
      * yfinance or another data source library for asset/market data
      * scikit-learn

A minimal conda environment could look like (example):
  conda create -n capm_env python=3.9
  conda activate capm_env
  pip install numpy pandas matplotlib seaborn scipy statsmodels

Or using pip only:
  pip install numpy pandas matplotlib seaborn scipy statsmodels


STEP-BY-STEP REPLICATION INSTRUCTIONS
-------------------------------------
1. Unzip this replication package
   - Extract the entire `Replication_Package` folder to a convenient location on your machine.

2. Set your working directory
   - In your terminal or command prompt, navigate to the folder that contains `Replication_Package`.
   - When you open Jupyter (or JupyterLab / VS Code), make sure the working directory is such that
     the subfolders `code/`, `data/`, `documentation/`, and `output/` are visible under `Replication_Package`.

3. Verify data files
   - Confirm that `data/chatgpt_survey_raw.csv` is present.
   - Confirm that `output/summary_all_portfolios.csv` is present (this may be overwritten if you rerun the analysis).

4. Open the main notebooks
   - Open `code/capm_portfolio_project.ipynb` first for the core FIN411X CAPM portfolio project analysis.
   - Open `code/portfolio_analysis.ipynb` for additional portfolio summaries and checks.

5. Run the notebooks cell-by-cell
   - Run each cell from top to bottom to ensure that:
       * All imports succeed.
       * File paths successfully locate data in `data/` and write outputs to `output/`.
   - If you encounter a `ModuleNotFoundError`, install the missing package using pip or conda, then rerun.

6. Check generated outputs
   - Inspect any newly created or updated files in `output/` (for example, `summary_all_portfolios.csv`).
   - Compare them with the included version (if you keep a backup) to verify that the replication is consistent.

7. Review survey documentation
   - Open `documentation/chatgpt_survey_instrument.pdf` to see the survey questions corresponding to the
     `chatgpt_survey_raw.csv` data.
   - Consult `documentation/python_code_notes.docx` for any additional notes about variable meanings,
     processing steps, or project-specific instructions.

8. (Optional) Document your exact environment
   - For full transparency and future replicability, consider recording:
       * The exact Python version (`python --version`).
       * The list of installed packages (`pip freeze` or `conda env export`).
       * Any changes you make to the notebooks or data.

NOTE: If your actual environment or package list differs from the example above, edit this README to specify
the precise versions you used (for example, "Python 3.11, pandas 2.2.1, numpy 1.26.4", etc.).
